package com.gl.patientsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
