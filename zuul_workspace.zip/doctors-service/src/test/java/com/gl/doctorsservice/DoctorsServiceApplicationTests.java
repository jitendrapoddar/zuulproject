package com.gl.doctorsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
